package br.com.khia.catracas_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatracasSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatracasSpringBootApplication.class, args);
	}

}
